"use client";
import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import Header from "@/components/Header";
import { templates } from "@/lib/templates";
type Draft = { event:string; name:string; date:string; time:string; place:string; message:string; };
const initial:Draft={event:"День рождения",name:"Анна",date:"2026-12-12",time:"16:00",place:"Ресторан «Лес»",message:"Буду рада разделить с вами этот особенный день!"};
export default function EditorPage() {
 const params=useSearchParams(); const selected=params.get("template")||"bloom";
 const template=templates.find(t=>t.id===selected)||templates[0];
 const [draft,setDraft]=useState<Draft>(initial);
 const [photo,setPhoto]=useState<string>(""); const [music,setMusic]=useState<string>(""); const [musicName,setMusicName]=useState("");
 useEffect(()=>{try{const saved=localStorage.getItem("neuro-invite-draft");if(saved)setDraft(JSON.parse(saved));}catch{}},[]);
 const update=(key:keyof Draft,value:string)=>setDraft(prev=>({...prev,[key]:value}));
 const dateLabel=useMemo(()=>draft.date?new Date(draft.date+"T12:00:00").toLocaleDateString("ru-RU",{day:"numeric",month:"long",year:"numeric"}):"Дата уточняется",[draft.date]);
 function save(){localStorage.setItem("neuro-invite-draft",JSON.stringify(draft));alert("Черновик сохранён в этом браузере на этом устройстве.");}
 function chooseFile(e:React.ChangeEvent<HTMLInputElement>,kind:"photo"|"music"){const f=e.target.files?.[0];if(!f)return;const url=URL.createObjectURL(f);if(kind==="photo")setPhoto(url);else{setMusic(url);setMusicName(f.name);}}
 return <main><Header/><section className="mx-auto max-w-6xl px-5 pb-20 pt-6"><Link href="/templates" className="text-sm font-semibold text-rose-600">← Назад к шаблонам</Link><div className="mt-4"><p className="text-xs font-bold uppercase tracking-[.2em] text-rose-500">Конструктор</p><h1 className="serif mt-2 text-4xl">Создайте своё приглашение</h1><p className="mt-2 text-sm text-stone-500">Выбран дизайн: {template.title}. Меняйте данные — предпросмотр обновляется сразу.</p></div>
 <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_.9fr]">
  <div className="space-y-6 rounded-3xl border border-stone-200 bg-white p-6">
   <div><h2 className="serif text-2xl">Детали события</h2><div className="mt-4 grid gap-4 sm:grid-cols-2">
    <label className="text-sm font-semibold">Тип события<input value={draft.event} onChange={e=>update("event",e.target.value)} className="mt-2 w-full rounded-xl border border-stone-200 px-4 py-3 font-normal"/></label>
    <label className="text-sm font-semibold">Имя / заголовок<input value={draft.name} onChange={e=>update("name",e.target.value)} className="mt-2 w-full rounded-xl border border-stone-200 px-4 py-3 font-normal"/></label>
    <label className="text-sm font-semibold">Дата<input type="date" value={draft.date} onChange={e=>update("date",e.target.value)} className="mt-2 w-full rounded-xl border border-stone-200 px-4 py-3 font-normal"/></label>
    <label className="text-sm font-semibold">Время<input type="time" value={draft.time} onChange={e=>update("time",e.target.value)} className="mt-2 w-full rounded-xl border border-stone-200 px-4 py-3 font-normal"/></label>
    <label className="text-sm font-semibold sm:col-span-2">Место проведения<input value={draft.place} onChange={e=>update("place",e.target.value)} className="mt-2 w-full rounded-xl border border-stone-200 px-4 py-3 font-normal"/></label>
    <label className="text-sm font-semibold sm:col-span-2">Текст приглашения<textarea rows={3} value={draft.message} onChange={e=>update("message",e.target.value)} className="mt-2 w-full rounded-xl border border-stone-200 px-4 py-3 font-normal"/></label>
   </div></div>
   <div className="border-t border-stone-100 pt-5"><h2 className="serif text-2xl">Ваши материалы</h2><div className="mt-4 grid gap-4 sm:grid-cols-2">
    <label className="cursor-pointer rounded-2xl border border-dashed border-rose-300 bg-rose-50/50 p-5 text-sm"><span className="block font-bold">＋ Добавить фото</span><span className="mt-1 block text-xs text-stone-500">JPG, PNG или WEBP</span><input type="file" accept="image/*" className="mt-3 block w-full text-xs" onChange={e=>chooseFile(e,"photo")}/></label>
    <label className="cursor-pointer rounded-2xl border border-dashed border-stone-300 bg-stone-50 p-5 text-sm"><span className="block font-bold">♫ Добавить музыку</span><span className="mt-1 block text-xs text-stone-500">MP3, M4A или WAV</span><input type="file" accept="audio/*" className="mt-3 block w-full text-xs" onChange={e=>chooseFile(e,"music")}/></label>
   </div>{musicName&&<div className="mt-3 text-xs text-stone-500">Выбран аудиофайл: {musicName}<audio controls src={music} className="mt-2 w-full"/></div>}
   <p className="mt-3 text-xs leading-5 text-stone-400">Фото и музыка пока отображаются только в этом предпросмотре. В облако они не загружаются.</p></div>
   <div className="flex flex-wrap gap-3"><button onClick={save} className="rounded-full bg-stone-900 px-6 py-3 text-sm font-bold text-white">Сохранить черновик</button><button onClick={()=>{setDraft(initial);setPhoto("");setMusic("");setMusicName("");}} className="rounded-full border border-stone-300 px-6 py-3 text-sm font-bold">Сбросить</button></div>
  </div>
  <aside><div className="sticky top-5"><div className="mb-3 flex items-center justify-between"><h2 className="font-bold">Предпросмотр</h2><span className="text-xs text-stone-400">Как увидят гости</span></div>
   <div className="mx-auto max-w-sm rounded-[34px] bg-gradient-to-br from-rose-100 via-orange-50 to-amber-100 p-5 shadow-xl"><div className="min-h-[510px] rounded-[26px] border border-white/80 bg-white/70 px-6 py-9 text-center">
    {photo?<img src={photo} alt="Фото для приглашения" className="mx-auto mb-6 h-40 w-40 rounded-full object-cover"/>:<div className="text-rose-400 text-4xl">{template.symbol}</div>}
    <p className="mt-7 text-[10px] tracking-[.35em] text-rose-600">{draft.event.toUpperCase()}</p><h3 className="serif mt-5 text-5xl break-words">{draft.name||"Ваше имя"}</h3><div className="mx-auto my-6 h-px w-20 bg-rose-300"/>
    <p className="mx-auto max-w-xs text-sm leading-7 text-stone-600">{draft.message}</p><p className="mt-8 font-bold tracking-wider">{dateLabel}</p><p className="mt-2 text-lg">{draft.time||"Время уточняется"}</p><p className="mt-5 text-sm text-stone-500">{draft.place||"Место проведения"}</p><div className="mt-8 text-rose-400">✧　✧　✧</div>
   </div></div><p className="mt-4 text-center text-xs text-stone-400">Это макет. Публикация и ссылка для гостей будут подключены на следующем этапе.</p>
  </div></aside>
 </div></section></main>;
}
