import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata = { title: "NEURO INVITE — приглашения с характером", description: "Создавайте красивые интерактивные приглашения онлайн." };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ru"><body>{children}</body></html>;
}
