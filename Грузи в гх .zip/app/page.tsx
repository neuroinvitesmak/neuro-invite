import Link from "next/link";
import Header from "@/components/Header";
import TemplateTile from "@/components/TemplateTile";
import { templates } from "@/lib/templates";
export default function Home() {
 return <main><Header />
  <section className="mx-auto grid max-w-6xl gap-10 px-5 pb-20 pt-10 md:grid-cols-[1.05fr_.95fr] md:items-center">
   <div><div className="mb-5 inline-flex rounded-full border border-rose-200 bg-rose-50 px-4 py-2 text-xs font-bold uppercase tracking-[.18em] text-rose-600">Приглашения нового поколения</div>
    <h1 className="serif max-w-xl text-5xl leading-[1.08] md:text-7xl">Ваш праздник.<br/><span className="text-rose-500">Ваша история.</span></h1>
    <p className="mt-6 max-w-lg text-lg leading-8 text-stone-600">Создайте красивое интерактивное приглашение за несколько минут. Добавьте детали события, фото и музыку — и отправьте гостям одну ссылку.</p>
    <div className="mt-8 flex flex-wrap gap-3"><Link href="/templates" className="rounded-full bg-stone-900 px-7 py-4 font-bold text-white">Выбрать дизайн</Link><Link href="/editor" className="rounded-full border border-stone-300 px-7 py-4 font-bold">Открыть конструктор</Link></div>
    <div className="mt-10 flex gap-8 text-sm text-stone-500"><span><b className="block text-2xl text-stone-900">01</b>Выберите стиль</span><span><b className="block text-2xl text-stone-900">02</b>Заполните детали</span><span><b className="block text-2xl text-stone-900">03</b>Отправьте ссылку</span></div>
   </div>
   <div className="relative mx-auto w-full max-w-md"><div className="absolute -inset-5 rounded-[40px] bg-rose-100/70 blur-2xl"/><div className="relative rotate-2 rounded-[34px] border border-white bg-gradient-to-br from-rose-100 via-orange-50 to-amber-100 p-8 shadow-2xl">
    <div className="rounded-[26px] border border-white/80 bg-white/65 px-7 py-12 text-center"><div className="text-rose-400">✿　✿　✿</div><p className="mt-8 text-xs tracking-[.35em] text-rose-600">ПРИГЛАШЕНИЕ</p><h2 className="serif mt-4 text-5xl">Анна</h2><p className="serif mt-1 text-3xl italic text-rose-500">и её день</p><div className="mx-auto my-7 h-px w-20 bg-rose-300"/><p className="text-sm leading-7 text-stone-600">Буду рада разделить с вами<br/>этот особенный момент</p><p className="mt-8 font-bold tracking-[.2em]">12 ДЕКАБРЯ · 16:00</p><div className="mt-8 text-rose-400">✧　✧　✧</div></div>
   </div></div>
  </section>
  <section className="bg-white py-20"><div className="mx-auto max-w-6xl px-5"><div className="flex items-end justify-between gap-4"><div><p className="text-xs font-bold uppercase tracking-[.2em] text-rose-500">Галерея дизайнов</p><h2 className="serif mt-3 text-4xl">Начните с вдохновения</h2></div><Link href="/templates" className="text-sm font-bold text-rose-600">Все шаблоны →</Link></div>
   <div className="mt-9 grid gap-6 md:grid-cols-3">{templates.slice(0,3).map(t=><TemplateTile key={t.id} item={t}/>)}</div>
  </div></section>
  <section id="pricing" className="mx-auto max-w-6xl px-5 py-20"><p className="text-xs font-bold uppercase tracking-[.2em] text-rose-500">Понятные тарифы</p><h2 className="serif mt-3 text-4xl">Выберите свой формат</h2><div className="mt-8 grid gap-5 md:grid-cols-3">{[{n:"START",p:"490 ₽",d:"Одно стильное приглашение, ссылка для гостей"},{n:"PREMIUM",p:"990 ₽",d:"Расширенное оформление, фото и музыкальный акцент"},{n:"VIP",p:"1 990 ₽",d:"Максимальная персонализация и особые детали"}].map(x=><div key={x.n} className="rounded-3xl border border-stone-200 bg-white p-7"><p className="text-xs font-bold tracking-[.2em] text-rose-500">{x.n}</p><p className="serif mt-4 text-4xl">{x.p}</p><p className="mt-3 min-h-12 text-sm leading-6 text-stone-500">{x.d}</p><Link href="/templates" className="mt-6 inline-block font-bold">Выбрать дизайн →</Link></div>)}</div><p className="mt-5 text-xs text-stone-400">Цены предварительные, оплата пока не подключена.</p></section>
  <footer className="border-t border-stone-200 px-5 py-8 text-center text-xs text-stone-400">© 2026 NEURO INVITE · Демонстрационная версия</footer>
 </main>;
}
